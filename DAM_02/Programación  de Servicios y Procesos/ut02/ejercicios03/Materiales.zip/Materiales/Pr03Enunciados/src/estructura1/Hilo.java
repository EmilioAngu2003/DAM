package estructura1;

public class Hilo implements Runnable {
   
	public void run() {

		//...
		System.out.println("Hilo ejecut�ndose");
		//...
	   
   }
	
}

 

    

 


