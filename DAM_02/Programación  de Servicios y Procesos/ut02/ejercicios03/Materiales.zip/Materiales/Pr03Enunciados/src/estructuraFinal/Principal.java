package estructuraFinal;

public class Principal 
{

   public static void main( String[] args )
   {
	    
	 Hilo hilo = new Hilo();
     Thread thread = new Thread (hilo);

     thread.start();

     
     //...
     System.out.println("Hilo principal ejecut�ndose");
     try{Thread.sleep(1000);} catch (Exception ex) {}
     //...
     
     hilo.finalizar();
     
     //...
     System.out.println("Hilo principal acabando...");
     try{Thread.sleep(1000);} catch (Exception ex) {}
     //...

   }

}

 

    

 


